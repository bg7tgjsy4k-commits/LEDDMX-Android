# LEDDMX Android Programmer — V1

Android-only BLE controller/protocol workbench for LEDDMX-00 family.

## Current verified functions
- BLE scan and connect
- Service FFE0 / characteristic FFE1 write
- FFF4 notification monitor
- 171–210 mode buttons
- Raw HEX transmit to FFE1
- TX/RX log
- 5833FF03 notification monitor

## Important scope
This build does NOT pretend that LED LAMP has a hidden SAVE command. Persistent rewriting of preset animation memory is not yet verified. The app is the test/programming base used to discover the actual animation data protocol.

## Build APK without a PC
Use the included GitHub Actions workflow. Create/import this project into a GitHub repository from your phone, then open **Actions → Build LEDDMX APK → Run workflow**. When it finishes, open the workflow run, download the `LEDDMX-Android-debug` artifact, extract the APK on Android, and install it.

Android may ask permission to install apps from the browser/files app; allow it only for the app you use to install this APK.
