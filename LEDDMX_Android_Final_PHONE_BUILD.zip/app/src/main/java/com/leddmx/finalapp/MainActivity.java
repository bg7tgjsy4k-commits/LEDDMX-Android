package com.leddmx.finalapp;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.*;
import android.bluetooth.le.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.os.*;
import android.view.*;
import android.widget.*;
import java.util.*;
import java.util.Locale;
import java.util.UUID;

public class MainActivity extends Activity {
    static final UUID FFE0=UUID.fromString("0000ffe0-0000-1000-8000-00805f9b34fb"), FFE1=UUID.fromString("0000ffe1-0000-1000-8000-00805f9b34fb"), FFF4=UUID.fromString("0000fff4-0000-1000-8000-00805f9b34fb");
    static final UUID S2=UUID.fromString("5833ff02-9b8b-5191-6142-22a4536ef123"), S3=UUID.fromString("5833ff03-9b8b-5191-6142-22a4536ef123"), CCCD=UUID.fromString("00002902-0000-1000-8000-00805f9b34fb");
    BluetoothAdapter adapter; BluetoothGatt gatt; BluetoothGattCharacteristic tx, notify1, notify2; BluetoothLeScanner scanner; ArrayList<BluetoothDevice> found=new ArrayList<>(); ArrayList<String> labels=new ArrayList<>(); ArrayAdapter<String> spinAdapter; Handler h=new Handler(Looper.getMainLooper());
    TextView status,log; Spinner devices; EditText hex; GridLayout grid;
    BluetoothGattCallback cb=new BluetoothGattCallback(){
      public void onConnectionStateChange(BluetoothGatt g,int st,int ns){ if(ns==BluetoothProfile.STATE_CONNECTED){ gatt=g; ui("CONNECTED"); h.postDelayed(()->{ try{g.discoverServices();}catch(Exception e){log("discover: "+e);} },300); } else {ui("DISCONNECTED ("+st+")");} }
      public void onServicesDiscovered(BluetoothGatt g,int st){ if(st!=BluetoothGatt.GATT_SUCCESS){log("services error "+st);return;} tx=get(g,FFE0,FFE1); notify1=get(g,FFE0,FFF4); notify2=get(g,S3); enable(notify1); enable(notify2); log("Services ready. FFE1="+(tx!=null)+" S3="+(notify2!=null)); }
      public void onCharacteristicChanged(BluetoothGatt g,BluetoothGattCharacteristic c,byte[] v){log("RX "+hex(v));}
      public void onCharacteristicChanged(BluetoothGatt g,BluetoothGattCharacteristic c){log("RX "+hex(c.getValue()));}
    };
    public void onCreate(Bundle b){super.onCreate(b);setContentView(R.layout.activity_main); status=findViewById(R.id.status);log=findViewById(R.id.log);devices=findViewById(R.id.devices);hex=findViewById(R.id.hex);grid=findViewById(R.id.modeGrid); spinAdapter=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,labels);devices.setAdapter(spinAdapter); adapter=((BluetoothManager)getSystemService(BLUETOOTH_SERVICE)).getAdapter(); scanner=adapter.getBluetoothLeScanner();
      findViewById(R.id.scan).setOnClickListener(v->scan()); findViewById(R.id.connect).setOnClickListener(v->connect()); findViewById(R.id.disconnect).setOnClickListener(v->close()); findViewById(R.id.sendHex).setOnClickListener(v->send(parse(hex.getText().toString()))); buildModes(); requestPerms(); }
    void buildModes(){for(int i=171;i<=210;i++){Button b=new Button(this);b.setText(String.valueOf(i));final int m=i;b.setOnClickListener(v->send(mode(m)));GridLayout.LayoutParams p=new GridLayout.LayoutParams();p.width=0;p.height=48;p.columnSpec=GridLayout.spec(GridLayout.UNDEFINED,1f);grid.addView(b,p);}}
    byte[] mode(int m){return new byte[]{0x7B,(byte)0xFF,0x03,(byte)m,(byte)0xFF,(byte)0xFF,(byte)0xFF,(byte)0xFF,(byte)0xBF};}
    BluetoothGattCharacteristic get(BluetoothGatt g,UUID su,UUID cu){BluetoothGattService s=g.getService(su);return s==null?null:s.getCharacteristic(cu);}
    void enable(BluetoothGattCharacteristic c){if(c==null||gatt==null)return;gatt.setCharacteristicNotification(c,true);BluetoothGattDescriptor d=c.getDescriptor(CCCD);if(d!=null){d.setValue(BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE);gatt.writeDescriptor(d);}}
    void send(byte[] data){if(gatt==null||tx==null){log("NOT CONNECTED / FFE1 unavailable");return;}tx.setValue(data);tx.setWriteType(BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE);boolean ok=gatt.writeCharacteristic(tx);log("TX FFE1 "+hex(data)+" -> "+ok);}
    void scan(){if(!has(Manifest.permission.BLUETOOTH_SCAN)&&Build.VERSION.SDK_INT>=31){requestPermissions(new String[]{Manifest.permission.BLUETOOTH_SCAN,Manifest.permission.BLUETOOTH_CONNECT},5);return;}found.clear();labels.clear();spinAdapter.notifyDataSetChanged();log("Scanning...");scanner.startScan(new ScanCallback(){public void onScanResult(int c,ScanResult r){BluetoothDevice d=r.getDevice();String n;try{n=d.getName();}catch(Exception e){n="?";}if(!found.contains(d)){found.add(d);labels.add(n+" • "+d.getAddress());spinAdapter.notifyDataSetChanged();if((n!=null&&n.contains("LEDDMX"))||d.getAddress().equalsIgnoreCase("FF:FF:11:87:B2:CD"))log("FOUND "+n+" "+d.getAddress());}}});h.postDelayed(()->{scanner.stopScan(new ScanCallback(){});log("Scan done: "+found.size()+" devices");},8000);}
    void connect(){if(found.size()==0){log("Scan first");return;}int i=devices.getSelectedItemPosition();if(i<0)return;try{if(gatt!=null)gatt.close();gatt=found.get(i).connectGatt(this,false,cb,BluetoothDevice.TRANSPORT_LE);}catch(Exception e){log("connect: "+e);}}
    void close(){if(gatt!=null){gatt.disconnect();gatt.close();gatt=null;}ui("DISCONNECTED");}
    void requestPerms(){if(Build.VERSION.SDK_INT>=31&&!has(Manifest.permission.BLUETOOTH_SCAN))requestPermissions(new String[]{Manifest.permission.BLUETOOTH_SCAN,Manifest.permission.BLUETOOTH_CONNECT},5);}
    boolean has(String p){return Build.VERSION.SDK_INT<23||checkSelfPermission(p)==PackageManager.PERMISSION_GRANTED;}
    void ui(String s){runOnUiThread(()->status.setText("LEDDMX Controller • "+s));}
    void log(String s){runOnUiThread(()->{log.append("\n"+s);});}
    static String hex(byte[] b){if(b==null)return "";StringBuilder x=new StringBuilder();for(byte q:b)x.append(String.format(Locale.US,"%02X ",q&255));return x.toString().trim();}
    static byte[] parse(String s){s=s.replaceAll("[^0-9A-Fa-f]","");if((s.length()&1)==1)throw new IllegalArgumentException("Odd HEX length");byte[] b=new byte[s.length()/2];for(int i=0;i<b.length;i++)b[i]=(byte)Integer.parseInt(s.substring(i*2,i*2+2),16);return b;}
}
